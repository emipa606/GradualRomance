﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using Verse;
using RimWorld;

namespace Gradual_Romance
{
    [DefOf]
    public static class FlirtReactionDefOf
    {
        public static FlirtReactionDef Ignorant;
    }
}
