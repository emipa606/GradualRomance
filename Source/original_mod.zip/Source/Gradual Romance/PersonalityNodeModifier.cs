﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using Psychology;

namespace Gradual_Romance
{
    public class PersonalityNodeModifier
    {
        public PersonalityNodeDef personalityNode;

        public bool reverse = false;

        public float modifier = 1f;


    }
}
