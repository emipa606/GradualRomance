﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using RimWorld;
using Verse;

namespace Gradual_Romance
{
    public class RomanticThoughtExtension : DefModExtension
    {
        bool isReasonForBreakup = false;
    }
}
