﻿using RimWorld;

namespace Gradual_Romance
{
    class PawnRelationWorker_RomanticInterest : PawnRelationWorker
    {

    }
}
