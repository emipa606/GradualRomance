﻿using RimWorld;

namespace Gradual_Romance
{
    public class PawnRelationWorker_Sweetheart : PawnRelationWorker
    {
    }
}
