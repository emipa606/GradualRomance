﻿using RimWorld;

namespace Gradual_Romance
{
    class PawnRelationWorker_LoveBuddy : PawnRelationWorker
    {
    }
}

