﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using RimWorld;

namespace Gradual_Romance
{
    [DefOf]
    public static class TraitDefOfGR
    {
        public static TraitDef Wimp;

        public static TraitDef Shy;

        public static TraitDef Nimble;

        public static TraitDef Immunity;

        public static TraitDef MelodicVoice;

        public static TraitDef Jealous;

        public static TraitDef Seductive;
    }
}
